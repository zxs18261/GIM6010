/**
  ******************************************************************************
  * @file    app_callbacks.c
  * @brief   GIM6010 HAL 回调聚合实现（移植自旧工程 Hardware/Timer.c 并扩展）
  * @note    - ADC 注入回调发生在 PWM 采样窗口：先锁存注入 Rank，再进电流环
  *          - 20kHz ISR 只投递 MT6816 DMA 采样请求/只读缓存，绝不轮询 SPI
  *          - 低频状态机/保护固定在 1kHz TIM2，绝不在此重复运行 High_Loop
  ******************************************************************************
  */
#include "app_callbacks.h"
#include "adc.h"
#include "SguanFOC.h"
#include "Sguan_printf.h"
#include "BSP_MT6816.h"
#include "BSP_ADC.h"
#include "canfd.h"
#include "usart.h"
#include "main.h"

/* ============================ 对外状态 ==================================== */
volatile uint32_t ADC_InjectedValues[4] = {0};

volatile uint32_t g_high_loop_cnt = 0;
volatile uint32_t g_high_loop_last_cycles = 0U;
volatile uint32_t g_high_loop_max_cycles = 0U;
volatile uint32_t g_high_loop_deadline_miss_cnt = 0U;
volatile APP_FocFaultSnapshot_t g_foc_fault_snapshot = {0};

/* ============================ 定时器回调 ================================== */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2) {
        /* 1kHz：低频状态机/速度位置环/保护 */
        SguanFOC_Low_Loop();
    }
    /* TIM4 的 PWM DMA 完成（WS2812B）由 BSP_WS2812B.c 的
     * HAL_TIM_PWM_PulseFinishedCallback 处理，此处不重复实现。 */
}

/* ============================ ADC 注入完成回调 ============================ */
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1) {
        uint32_t start_cycles = DWT->CYCCNT;
        uint32_t used_cycles;
        static uint32_t deadline_cycles = 0U;

        if (deadline_cycles == 0U) {
            deadline_cycles = SystemCoreClock / USER_FOC_CONTROL_HZ;
        }

        /* 先锁存注入 Rank：R1=IV, R2=IW, R3=VBUS(快速通道) */
        ADC_InjectedValues[0] = HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_1);
        ADC_InjectedValues[1] = HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_2);
        ADC_InjectedValues[2] = HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_3);
        BSP_ADC_FeedVBUSFast(ADC_InjectedValues[2]);

        g_high_loop_cnt++;
        /* 编码器采样：DMA 投递链在 FOC 使能后不稳定（2026-08-30 台架，见
         * BSP_MT6816_PollBlocking 注释），现由主循环 1kHz 阻塞直读，ISR 不再投递。 */

        SguanFOC_High_Loop();

        used_cycles = DWT->CYCCNT - start_cycles;
        g_high_loop_last_cycles = used_cycles;
        if (used_cycles > g_high_loop_max_cycles) {
            g_high_loop_max_cycles = used_cycles;
        }
        if (used_cycles >= deadline_cycles) {
            g_high_loop_deadline_miss_cnt++;
        }
    }
}

/* ============================ 串口回调 ==================================== */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == USART1) {
        SguanFOC_Printf_Loop(Sguan_PrintfBuff, Size);
        HAL_UARTEx_ReceiveToIdle_DMA(&huart1, Sguan_PrintfBuff, sizeof(Sguan_PrintfBuff));
        __HAL_DMA_DISABLE_IT(huart1.hdmarx, DMA_IT_HT);
    }
}

/* ============================ FDCAN 回调 ================================== */
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
    if ((hfdcan->Instance == FDCAN1) &&
        ((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) != 0U)) {
        CANFD_OnRxIsr();
    }
}
