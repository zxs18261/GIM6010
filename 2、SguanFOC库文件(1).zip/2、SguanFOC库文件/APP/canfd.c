/**
  ******************************************************************************
  * @file    canfd.c
  * @brief   GIM6010 多轴 FDCAN 协议实现（基础子集）
  * @note    - RX 在中断中仅做“拷贝到命令缓存”，语义解析在 CANFD_Poll（主循环）执行，
  *            避免在 CAN 中断里触碰 Sguan 控制量。
  *          - 位置命令单位：输出轴 µrad；内部换算为电机轴 rad（×减速比 8 / 1e6）。
  ******************************************************************************
  */
#include "canfd.h"
#include "fdcan.h"
#include "SguanFOC.h"
#include "BSP_MT6816.h"
#include "UserData_Config.h"
#include "main.h"
#include <string.h>

/* ============================ 内部状态 ==================================== */
static volatile uint8_t  s_rx_pending = 0U;     /* ISR→主循环 命令待处理标志 */
static uint8_t           s_rx_data[8];          /* 最近命令帧副本 */
static uint32_t          s_last_telem_ms = 0U;
static volatile uint8_t  s_online = 0U;

/* ============================ 初始化 ====================================== */
void CANFD_Init(void)
{
    FDCAN_FilterTypeDef filter;

    /* 只接收本节点命令帧；广播同步帧滤波器后续迭代再加 */
    filter.IdType = FDCAN_STANDARD_ID;
    filter.FilterIndex = 0U;
    filter.FilterType = FDCAN_FILTER_RANGE;
    filter.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
    filter.FilterID1 = CANFD_ID_CMD;
    filter.FilterID2 = CANFD_ID_CMD;
    if (HAL_FDCAN_ConfigFilter(&hfdcan1, &filter) != HAL_OK) {
        Error_Handler();
    }
    /* 非匹配帧全部拒收（标准/扩展），远程帧拒收 */
    if (HAL_FDCAN_ConfigGlobalFilter(&hfdcan1, FDCAN_REJECT, FDCAN_REJECT,
                                     FDCAN_REJECT_REMOTE, FDCAN_REJECT_REMOTE) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0U) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK) {
        Error_Handler();
    }
}

/* ============================ 接收（中断） ================================ */
void CANFD_OnRxIsr(void)
{
    FDCAN_RxHeaderTypeDef header;

    if (HAL_FDCAN_GetRxMessage(&hfdcan1, FDCAN_RX_FIFO0, &header, s_rx_data) == HAL_OK) {
        if ((header.Identifier == CANFD_ID_CMD) && (header.DataLength == 8U)) {
            s_rx_pending = 1U;   /* 解析留给主循环 */
            s_online = 1U;
        }
    }
}

/* ============================ 命令解析（主循环） =========================== */
static void CANFD_ParseCmd(const uint8_t *d)
{
    int32_t pos_urad;
    int16_t speed_rpm;
    uint16_t cmd = (uint16_t)((uint16_t)d[6] | ((uint16_t)d[7] << 8));

    /* 1.模式位（与 VOFA BO 一致的四种模式） */
    if ((cmd & CANFD_CMD_MODE_MASK) != 0U) {
        Sguan.mode = (uint8_t)((cmd & CANFD_CMD_MODE_MASK) >> CANFD_CMD_MODE_SHIFT);
    }

    /* 2.控制字 */
    if ((cmd & CANFD_CMD_DIS) != 0U) {
        Sguan.foc.Target_Pos = Sguan.encoder.Real_Pos;  /* 原地保持后软停 */
        Sguan.foc.Target_Speed = 0.0f;
    }
    if ((cmd & CANFD_CMD_SETZERO) != 0U) {
        Sguan.foc.Target_Pos = 0.0f;
        Sguan.encoder.Real_Pos = 0.0f;
    }
    if ((cmd & CANFD_CMD_FAULT_CLEAR) != 0U) {
        if ((Sguan.status == MOTOR_STATUS_STANDBY) || (Sguan.status >= 19)) {
            Sguan.status = MOTOR_STATUS_UNINITIALIZED;
        }
    }
    if ((cmd & CANFD_CMD_EN) != 0U) {
        if (Sguan.status == MOTOR_STATUS_STANDBY) {
            Sguan.status = MOTOR_STATUS_UNINITIALIZED;
        }
    }

    /* 3.速度限幅（输出轴 rpm → 电机轴 rad/s，写入速度环上限所在的目标链路预留） */
    speed_rpm = (int16_t)((uint16_t)d[4] | ((uint16_t)d[5] << 8));
    (void)speed_rpm;   /* 本期速度限幅暂不接入 STA 速度环，仅保留字段 */

    /* 4.位置目标：输出轴 µrad → 电机轴 rad（相对 Real_Pos 基准） */
    (void)memcpy(&pos_urad, d, 4);
    {
        float shaft_rad = (float)pos_urad / CANFD_URAD_PER_RAD;
        Sguan.foc.Target_Pos = shaft_rad * GIM6010_GEAR_RATIO;
    }
}

/* ============================ 遥测发送（主循环） =========================== */
void CANFD_Poll(void)
{
    uint32_t now;
    FDCAN_TxHeaderTypeDef tx;
    uint8_t data[8];
    int32_t pos_urad;
    int16_t rpm;
    uint16_t stat;
    float shaft_rad;
    float shaft_rpm;

    if (s_rx_pending != 0U) {
        s_rx_pending = 0U;
        CANFD_ParseCmd(s_rx_data);
    }

    now = HAL_GetTick();
    if ((now - s_last_telem_ms) < CANFD_TELEM_PERIOD_MS) {
        return;
    }
    s_last_telem_ms = now;

    /* 输出轴位置（MT6816 缓存）与转速（PLL，电机轴）→ 输出轴 */
    shaft_rad = BSP_MT6816_GetMechRad() / GIM6010_GEAR_RATIO;
    shaft_rpm = Sguan.encoder.Real_Speed * USER_RADS2RPM / GIM6010_GEAR_RATIO;

    pos_urad = (int32_t)(shaft_rad * CANFD_URAD_PER_RAD);
    rpm = (int16_t)shaft_rpm;
    stat = (uint16_t)(((uint16_t)Sguan.mode << 8) | (Sguan.status & 0xFFU));

    (void)memcpy(data, &pos_urad, 4);
    data[4] = (uint8_t)((uint16_t)rpm & 0xFFU);
    data[5] = (uint8_t)(((uint16_t)rpm >> 8) & 0xFFU);
    data[6] = (uint8_t)(stat & 0xFFU);
    data[7] = (uint8_t)((stat >> 8) & 0xFFU);

    tx.Identifier = CANFD_ID_TELEM;
    tx.IdType = FDCAN_STANDARD_ID;
    tx.TxFrameType = FDCAN_DATA_FRAME;
    tx.DataLength = FDCAN_DLC_BYTES_8;
    tx.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    tx.BitRateSwitch = FDCAN_BRS_OFF;
    tx.FDFormat = FDCAN_CLASSIC_CAN;
    tx.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
    tx.MessageMarker = 0U;

    if (HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1) > 0U) {
        (void)HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &tx, data);
    }
}

uint8_t CANFD_IsOnline(void)
{
    return s_online;
}
