/**
  ******************************************************************************
  * @file    canfd.h
  * @brief   GIM6010 多轴 FDCAN 协议（基础子集，DOC/GIM6010.md §12.2）
  * @note    总线：1 Mbps 经典帧（波特率覆盖在 Core/Src/fdcan.c 用户段）
  *          帧 ID：命令 0x100+ID / 遥测 0x200+ID / 同步 0x7FF(预留)
  ******************************************************************************
  */

#ifndef __CANFD_H
#define __CANFD_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* ============================ 节点与帧 ID ============================ */
#ifndef CANFD_NODE_ID
#define CANFD_NODE_ID           (1U)    /* 本板节点号（机械臂 1~6 轴，后续改 Flash/拨码） */
#endif

#define CANFD_ID_CMD            (0x100U + CANFD_NODE_ID)  /* 主→从 命令帧 */
#define CANFD_ID_TELEM          (0x200U + CANFD_NODE_ID)  /* 从→主 遥测帧 */
#define CANFD_ID_SYNC           (0x7FFU)                  /* 主→从 广播同步(预留) */

#define CANFD_TELEM_PERIOD_MS   (2U)    /* 遥测周期 500Hz（1kHz 时隙方案后续迭代） */

/* ============================ 命令帧 (8B) ============================ */
/*  [0..3] int32  目标位置 µrad（输出轴）
 *  [4..5] int16  速度限幅 rpm（输出轴，0=不改变）
 *  [6..7] uint16 命令位：
 *      bit0     使能（触发初始化/对齐）
 *      bit1     故障复位（STANDBY/锁定 → UNINITIALIZED）
 *      bit2     失能（软停）
 *      bit3..4  模式：0开环 1电流 2速度 3位置
 *      bit5     位置零点重置（Target/Real 归零）                    */
#define CANFD_CMD_EN            (0x0001U)
#define CANFD_CMD_FAULT_CLEAR   (0x0002U)
#define CANFD_CMD_DIS           (0x0004U)
#define CANFD_CMD_MODE_MASK     (0x0018U)
#define CANFD_CMD_MODE_SHIFT    (3U)
#define CANFD_CMD_SETZERO       (0x0020U)

/* ============================ 遥测帧 (8B) ============================ */
/*  [0..3] int32  输出轴位置 µrad
 *  [4..5] int16  输出轴转速 rpm
 *  [6..7] uint16 bit0..7=Sguan.status，bit8..11=Sguan.mode，bit12..15=保留 */
#define CANFD_URAD_PER_RAD      (1000000.0f)

/* ============================ 接口 ==================================== */
void CANFD_Init(void);          /* 滤波器 + 启动 + 开 RX 中断（波特率在 fdcan.c 用户段覆盖） */
void CANFD_OnRxIsr(void);       /* RX FIFO0 中断入口（app_callbacks 转发），快速解析后立即返回 */
void CANFD_Poll(void);          /* 主循环：遥测发送节拍 */

uint8_t CANFD_IsOnline(void);   /* 1=上电后收到过命令帧（联调指示） */

#ifdef __cplusplus
}
#endif

#endif /* __CANFD_H */
