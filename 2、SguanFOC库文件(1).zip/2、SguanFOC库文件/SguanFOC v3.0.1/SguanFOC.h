#ifndef __SGUANFOC_H
#define __SGUANFOC_H

/* USER CODE BEGIN Includes */
// 电机控制核心函数文件声明
#include "Sguan_Config.h"
#include "Sguan_Filter.h"
#include "Sguan_MotorStatus.h"
#include "Sguan_Optimize.h"
#include "Sguan_PID.h"
#include "Sguan_PLL.h"
#include "Sguan_printf.h"
#include "Sguan_STA.h"
#include "Sguan_SVPWM.h"
/* USER CODE END Includes */

#define Velocity_OPEN_MODE          0x00 // 速度开环(Uq_in电机方向测试和电机参数测算)
#define Current_SINGLE_MODE         0x01 // 电流单闭环(力矩控制)
#define VelCur_DOUBLE_MODE          0x02 // 速度-电流串级闭环控制
#define PosVelCur_THREE_MODE        0x03 // 位置-速度-电流多环

typedef struct{
    uint8_t Angle_Calc;                 // 电机读取角度校正和转子极性辨识“标志位”

    uint8_t PWM_Calc;                   // PWM计算“标志位”
    uint8_t PWM_watchdog_limit;         // PWM错误限幅(uint8_t够用，PWM计算不能错误太多次)

    uint8_t in_PWM_Calc_ISR;            // (互斥锁)标记是否在PWM计算中断中
}MOTOR_FLAG_STRUCT;


// =============================== float 版本代码 ===============================

#if !CONFIG_Q31
typedef struct{
    LPF_STRUCT CurrentD;                // (电流数据)电机D轴滤波
    LPF_STRUCT CurrentQ;                // (电流数据)电机Q轴滤波
    LPF_STRUCT Encoder;                 // (速度数据)速度信号滤波
}MOTOR_LPF_STRUCT;

typedef struct{
    PID_STRUCT Current_D;               // (电流单环)PID电流环D轴参数
    PID_STRUCT Current_Q;               // (电流单环)PID电流环Q轴参数

    #if Open_PI_Control
    PID_STRUCT Velocity;                // (速度-电流双环)双PID速度外环参数
    #else // Open_PI_Control
    STA_STRUCT Speed;                   // (速度-电流双环)双PID速度外环参数
    #endif // Open/_PI_Control
    
    PID_STRUCT Position;                // (高性能伺服三环)Position

    uint8_t Response;                   // (参数设计)响应带宽倍数
}MOTOR_CONTROL_STRUCT;

typedef struct{
    uint8_t Poles;                      // (电机实体参数)电机极对极数
    float VBUS;                         // (电机实体参数)母线电压

    int8_t Motor_Dir;                   // (参数设计)电机的运行方向设计
    int8_t PWM_Dir;                     // (参数设计)PWM占空比高低对应
    uint16_t Duty;                      // (参数设计)PWM满占空比

    int8_t Encoder_Dir;                 // (参数设计)编码器的方向设置

    int8_t Current_Dir0;                // (参数设计)电流采样方向0
    int8_t Current_Dir1;                // (参数设计)电流采样方向1
    uint8_t Current_Num;                // (参数设计)电流通道0->AB相，1->AC相，2->BC相
    uint32_t ADC_Precision;             // (参数设计)ADC采样精度,如12位精度为4096
    float Amplifier;                    // (参数设计)运放的放大倍数
    float MCU_Voltage;                  // (参数设计)DSP/单片机的ADC基准电压
    float Sampling_Rs;                  // (参数设计)采样电阻的阻值大小
}MOTOR_QUANTIZE_STRUCT;

typedef struct{
    float Ld;                           // (电机实体参数)D轴电感
    float Lq;                           // (电机实体参数)Q轴电感
    float Rs;                           // (电机实体参数)相线电阻
    float Flux;                         // (电机实体参数)电机磁链
}MOTOR_IDENTIFY_STRUCT;

typedef struct{    
    float VBUS_MAX;                     // (参数设计)母线电压值波动MAX阈值
    float VBUS_MIM;                     // (参数设计)母线电压值波动MIN阈值
    uint32_t VBUS_watchdog_limit;       // (参数设计)电压异常的警告周期
    // 如果有电机电压预警，电机正常运行...经过Sguan_Low_Loop()的VBUS_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发电压警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行
    
    float Temp_MAX;                     // (参数设计)驱动器允许最大温度
    float Temp_MIN;                     // (参数设计)驱动器允许最小温度
    uint32_t Temp_watchdog_limit;       // (参数设计)温度异常的警告周期
    // 如果有驱动器温度预警，电机正常运行...经过Sguan_Low_Loop()的Temp_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发温度警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行
 
    float Dcur_MAX;                     // (参数设计)电机最大电流D轴限制
    float Qcur_MAX;                     // (参数设计)电机最大电流Q轴限制
    uint32_t DQcur_watchdog_limit;      // (参数设计)过流保护的警告周期
    // 如果有电机过流预警，电机正常运行...经过Sguan_Low_Loop()的DQcur_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发过流警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行

    float Current_limit;                // (参数设计)电流正负区间设计，电流状态机判断
    float Speed_limit;                  // (参数设计)速度正负区间设计，速度状态机判断
    float Position_limit;               // (参数设计)位置正负区间设计，位置状态机判断

    uint32_t DISABLED_watchdog_limit;   //(参数设计)电机DISABLED状态机进待机模式的延时周期
}MOTOR_SAFE_STRUCT;

typedef struct{
    float Target_Speed;                 // (期望速度)Target期望机械角速度
    float Target_Pos;                   // (期望角度)Target期望机械角度
    float Target_Id;                    // (期望电流)期望D轴电流
    float Target_Iq;                    // (期望电流)期望Q轴电流

    float Ud_in;                        // (输入值)D轴电压输入
    float Uq_in;                        // (输入值)Q轴电压输入

    uint16_t Duty_u;                    // (输入值)U相占空比输入0~pwmMAX
    uint16_t Duty_v;                    // (输入值)V相占空比输入0~pwmMAX
    uint16_t Duty_w;                    // (输入值)W相占空比输入0~pwmMAX

    float Du;                           // (数据)U相占空比输入0~1
    float Dv;                           // (数据)V相占空比输入0~1
    float Dw;                           // (数据)W相占空比输入0~1

    float sine;                         // (数据)sine临时保存的正弦值
    float cosine;                       // (数据)cosine临时保存的余弦值

    float Real_VBUS;                    // (数据)Real实际的电机母线电压
    float Real_Temp;                    // (数据)Temp实际的驱动器物理温度
}MOTOR_FOC_STRUCT;

typedef struct{
    PLL_STRUCT pll;                     // (PLL锁相环)锁相环结构体

    float Real_Speed;                   // (Encoder速度)Real实际机械角速度
    double Real_Pos;                    // (Encoder多圈角度)Real实际机械角度
    float Real_Rad;                     // (Encoder单圈角度)Real实际机械角度
    float Real_Erad;                    // (Encoder电角度)Real实际电子角度
    float Real_Espeed;                  // (Encoder电速度)Real实际电子角速度

    float Pos_offset;                   // (Encoder角度偏置)offset偏置位
}MOTOR_ENCODER_STRUCT;

typedef struct{
    float Real_Id;                      // (Current电流)Real实际D轴电流
    float Real_Iq;                      // (Current电流)Real实际Q轴电流

    float Real_Ia;                      // (Current相电流)A相电流
    float Real_Ib;                      // (Current相电流)B相电流
    float Real_Ic;                      // (Current相电流)C相电流

    float Real_Ialpha;                  // (Current中间量电流)alpha轴电流
    float Real_Ibeta;                   // (Current中间量电流)beta轴电流

    float Final_Gain;                   // (ADC增益)最终的ADC电流采样增益
    int32_t Current_offset0;            // (Current电流偏置)offset偏置位
    int32_t Current_offset1;            // (Current电流偏置)offset偏置位
}MOTOR_CURRENT_STRUCT;

typedef struct{
    uint8_t status;                     // 【数据】status存储电机运行状态
    uint8_t mode;                       // 【有参数设计】mode选择电机的运行模式
    MOTOR_FLAG_STRUCT flag;             // 【有参数设计】flag电机运行标志位
    
    MOTOR_LPF_STRUCT lpf;               // 【有参数设计】bpf低通滤波器设计
    MOTOR_CONTROL_STRUCT control;       // 【有参数设计】闭环控制系统设计
    MOTOR_QUANTIZE_STRUCT motor;        // 【有参数设计】motor电机参数量化
    MOTOR_IDENTIFY_STRUCT identify;     // 【数据】identify电机参数辨识结果
    
    MOTOR_SAFE_STRUCT safe;             // 【有参数设计】safe电机安全设置
    MOTOR_FOC_STRUCT foc;               // 【有参数设计】foc控制的参数输入“缓存”
    MOTOR_ENCODER_STRUCT encoder;       // 【数据】电机角速度和角度信息“缓存”
    MOTOR_CURRENT_STRUCT current;       // 【数据】电机电流采样信息“缓存”

    PRINTF_STRUCT TXdata;               // 【数据】data串口或CAN发送的信息
}SguanFOC_System_STRUCT;


// =============================== Q31 版本代码 ===============================

#else // CONFIG_Q31
typedef struct{
    LPF_STRUCT_q31 CurrentD;            // (电流数据)电机D轴滤波
    LPF_STRUCT_q31 CurrentQ;            // (电流数据)电机Q轴滤波
    LPF_STRUCT_q31 Encoder;             // (速度数据)速度信号滤波
}MOTOR_LPF_STRUCT_q31;

typedef struct{
    PID_STRUCT_q31 Current_D;           // (电流单环)PID电流环D轴参数
    PID_STRUCT_q31 Current_Q;           // (电流单环)PID电流环Q轴参数

    #if Open_PI_Control
    PID_STRUCT_q31 Velocity;            // (速度-电流双环)双PID速度外环参数
    #else // Open_PI_Control
    STA_STRUCT_q31 Speed;               // (速度-电流双环)双PID速度外环参数
    #endif // Open/_PI_Control
    
    PID_STRUCT_q31 Position;            // (高性能伺服三环)Position

    uint8_t Response;                   // (参数设计)响应带宽倍数
}MOTOR_CONTROL_STRUCT_q31;

typedef struct{
    uint8_t Poles;                      // (电机实体参数)电机极对极数
    float VBUS;                         // (电机实体参数)母线电压
    Q31_t VBUS_q31;                     // (电机实体参数)母线电压
    
    int8_t Motor_Dir;                   // (参数设计)电机的运行方向设计
    int8_t PWM_Dir;                     // (参数设计)PWM占空比高低对应
    uint16_t Duty;                      // (参数设计)PWM满占空比

    int8_t Encoder_Dir;                 // (参数设计)编码器的方向设置

    int8_t Current_Dir0;                // (参数设计)电流采样方向0
    int8_t Current_Dir1;                // (参数设计)电流采样方向1
    uint8_t Current_Num;                // (参数设计)电流通道0->AB相，1->AC相，2->BC相
    uint32_t ADC_Precision;             // (参数设计)ADC采样精度,如12位精度为4096
    float Amplifier;                    // (参数设计)运放的放大倍数
    float MCU_Voltage;                  // (参数设计)DSP/单片机的ADC基准电压
    float Sampling_Rs;                  // (参数设计)采样电阻的阻值大小
}MOTOR_QUANTIZE_STRUCT_q31;

typedef struct{
    float Ld;                           // (电机实体参数)D轴电感
    float Lq;                           // (电机实体参数)Q轴电感
    float Rs;                           // (电机实体参数)相线电阻
    float Flux;                         // (电机实体参数)电机磁链

    Q31_t Ld_q31;                       // (电机实体参数)D轴电感
    Q31_t Lq_q31;                       // (电机实体参数)Q轴电感
    Q31_t Rs_q31;                       // (电机实体参数)相线电阻
    Q31_t Flux_q31;                     // (电机实体参数)电机磁链
}MOTOR_IDENTIFY_STRUCT_q31;

typedef struct{    
    float VBUS_MAX;                     // (参数设计)母线电压值波动MAX阈值
    float VBUS_MIM;                     // (参数设计)母线电压值波动MIN阈值
    uint32_t VBUS_watchdog_limit;       // (参数设计)电压异常的警告周期
    // 如果有电机电压预警，电机正常运行...经过Sguan_Low_Loop()的VBUS_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发电压警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行
    
    float Temp_MAX;                     // (参数设计)驱动器允许最大温度
    float Temp_MIN;                     // (参数设计)驱动器允许最小温度
    uint32_t Temp_watchdog_limit;       // (参数设计)温度异常的警告周期
    // 如果有驱动器温度预警，电机正常运行...经过Sguan_Low_Loop()的Temp_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发温度警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行
 
    float Dcur_MAX;                     // (参数设计)电机最大电流D轴限制
    float Qcur_MAX;                     // (参数设计)电机最大电流Q轴限制
    Q31_t Dcur_MAX_q31;                 // (参数设计)电机最大电流D轴限制
    Q31_t Qcur_MAX_q31;                 // (参数设计)电机最大电流Q轴限制
    uint32_t DQcur_watchdog_limit;      // (参数设计)过流保护的警告周期
    // 如果有电机过流预警，电机正常运行...经过Sguan_Low_Loop()的DQcur_watchdog_limit此运行周期
    // 若2-10次，中间有一次再触发过流警告，电机停转进待机
    // 若首次后10次，都未再触发，电机以后都正常运行

    float Current_limit;                // (参数设计)电流正负区间设计，电流状态机判断
    float Speed_limit;                  // (参数设计)速度正负区间设计，速度状态机判断
    float Position_limit;               // (参数设计)位置正负区间设计，位置状态机判断

    Q31_t Current_limit_q31;                // (参数设计)电流正负区间设计，电流状态机判断
    Q31_t Speed_limit_q31;                  // (参数设计)速度正负区间设计，速度状态机判断
    Q31_t Position_limit_q31;               // (参数设计)位置正负区间设计，位置状态机判断

    uint32_t DISABLED_watchdog_limit;   // (参数设计)电机DISABLED状态机进待机模式的延时周期
}MOTOR_SAFE_STRUCT_q31;

typedef struct{
    float Target_Speed;                 // (期望速度)Target期望机械角速度
    float Target_Pos;                   // (期望角度)Target期望机械角度
    float Target_Id;                    // (期望电流)期望D轴电流
    float Target_Iq;                    // (期望电流)期望Q轴电流

    Q31_t Target_Speed_q31;             // (期望速度)Target期望机械角速度
    Q31_t Target_Pos_q31;               // (期望角度)Target期望机械角度
    Q31_t Target_Id_q31;                // (期望电流)期望D轴电流
    Q31_t Target_Iq_q31;                // (期望电流)期望Q轴电流

    float Ud_in;                        // (输入值)D轴电压输入
    float Uq_in;                        // (输入值)Q轴电压输入

    Q31_t Ud_in_q31;                    // (输入值)D轴电压输入
    Q31_t Uq_in_q31;                    // (输入值)Q轴电压输入

    uint16_t Duty_u;                    // (输入值)U相占空比输入0~pwmMAX
    uint16_t Duty_v;                    // (输入值)V相占空比输入0~pwmMAX
    uint16_t Duty_w;                    // (输入值)W相占空比输入0~pwmMAX

    float Du;                           // (数据)U相占空比输入0~1
    float Dv;                           // (数据)V相占空比输入0~1
    float Dw;                           // (数据)W相占空比输入0~1

    Q31_t Du_q31;                       // (数据)U相占空比输入0~1
    Q31_t Dv_q31;                       // (数据)V相占空比输入0~1
    Q31_t Dw_q31;                       // (数据)W相占空比输入0~1

    Q31_t sine_q31;                     // (数据)sine临时保存的正弦值
    Q31_t cosine_q31;                   // (数据)cosine临时保存的余弦值

    float Real_VBUS;                    // (数据)Real实际的电机母线电压
    float Real_Temp;                    // (数据)Temp实际的驱动器物理温度
}MOTOR_FOC_STRUCT_q31;

typedef struct{
    PLL_STRUCT_q31 pll;                 // (PLL锁相环)锁相环结构体

    #if CONFIG_Float
    float Real_Speed;                   // (Encoder速度)Real实际机械角速度
    float Real_Pos;                     // (Encoder多圈角度)Real实际机械角度
    #endif // CONFIG_Float

    Q31_t Real_Speed_q31;               // (Encoder速度)Real实际机械角速度
    Q31_t Real_Pos_q31;                 // (Encoder多圈角度)Real实际机械角度
    Q31_t Real_Rad_q31;                 // (Encoder单圈角度)Real实际机械角度
    Q31_t Real_Erad_q31;                // (Encoder电角度)Real实际电子角度
    Q31_t Real_Espeed_q31;              // (Encoder电速度)Real实际电子角速度

    Q31_t Pos_offset_q31;               // (Encoder角度偏置)offset偏置位
}MOTOR_ENCODER_STRUCT_q31;

typedef struct{
    #if CONFIG_Float
    float Real_Id;                      // (Current电流)Real实际D轴电流
    float Real_Iq;                      // (Current电流)Real实际Q轴电流
    #endif // CONFIG_Float

    Q31_t Real_Id_q31;                  // (Current电流)Real实际D轴电流
    Q31_t Real_Iq_q31;                  // (Current电流)Real实际Q轴电流

    Q31_t Real_Ia_q31;                  // (Current相电流)A相电流
    Q31_t Real_Ib_q31;                  // (Current相电流)B相电流
    Q31_t Real_Ic_q31;                  // (Current相电流)C相电流

    Q31_t Real_Ialpha_q31;              // (Current中间量电流)alpha轴电流
    Q31_t Real_Ibeta_q31;               // (Current中间量电流)beta轴电流

    Q31_t Final_Gain_q31;               // (ADC增益)最终的ADC电流采样增益

    int32_t Current_offset0;            // (Current电流偏置)offset偏置位
    int32_t Current_offset1;            // (Current电流偏置)offset偏置位
}MOTOR_CURRENT_STRUCT_q31;

typedef struct{
    uint8_t status;                     // 【数据】status存储电机运行状态
    uint8_t mode;                       // 【有参数设计】mode选择电机的运行模式
    MOTOR_FLAG_STRUCT flag;             // 【有参数设计】flag电机运行标志位
    
    uint8_t IQmath_Error;               // 【数据】Q31_Init_Error定点标志位
    float IQmath_RX[6];                 // 【数据】Q31转换“定点数”标志位
    
    MOTOR_LPF_STRUCT_q31 lpf;           // 【有参数设计】bpf低通滤波器设计
    MOTOR_CONTROL_STRUCT_q31 control;   // 【有参数设计】闭环控制系统设计
    MOTOR_QUANTIZE_STRUCT_q31 motor;    // 【有参数设计】motor电机参数量化
    MOTOR_IDENTIFY_STRUCT_q31 identify; // 【数据】identify电机参数辨识结果
    MOTOR_SAFE_STRUCT_q31 safe;         // 【有参数设计】safe电机安全设置
    MOTOR_FOC_STRUCT_q31 foc;           // 【有参数设计】foc控制的参数输入“缓存”
    MOTOR_ENCODER_STRUCT_q31 encoder;   // 【数据】电机角速度和角度信息“缓存”
    MOTOR_CURRENT_STRUCT_q31 current;   // 【数据】电机电流采样信息“缓存”

    PRINTF_STRUCT TXdata;               // 【数据】data串口或CAN发送的信息
}SguanFOC_System_STRUCT;
#endif // CONFIG_Q31

// 电机控制核心结构体声明
extern SguanFOC_System_STRUCT Sguan;

void SguanFOC_High_Loop(void);
void SguanFOC_Low_Loop(void);
void SguanFOC_Printf_Loop(uint8_t *data, uint16_t length);
void SguanFOC_main_Loop(void);


#endif // SGUANFOC_H
