param(
    [Parameter(Mandatory = $false)]
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'

function Assert-Match {
    param(
        [string]$Name,
        [string]$Text,
        [string]$Pattern
    )
    if ($Text -notmatch $Pattern) {
        throw "FAIL: $Name"
    }
    Write-Output "PASS: $Name"
}

$configPath = Join-Path $ProjectRoot 'SguanFOC v3.0.1\UserData_Config.h'
$functionPath = Join-Path $ProjectRoot 'SguanFOC v3.0.1\UserData_Function.h'
$telemetryPath = Join-Path $ProjectRoot 'SguanFOC v3.0.1\UserData_UserControl.h'
$corePath = Join-Path $ProjectRoot 'SguanFOC v3.0.1\SguanFOC.c'

$config = Get-Content -Raw -LiteralPath $configPath
$functions = Get-Content -Raw -LiteralPath $functionPath
$telemetry = Get-Content -Raw -LiteralPath $telemetryPath
$core = Get-Content -Raw -LiteralPath $corePath

Assert-Match 'current feedforward disabled' $config '#define\s+USER_CURRENT_FEEDFORWARD_ENABLE\s+0(?:\s|$)'
Assert-Match 'closed-loop DQ limit is 0.30 V' $config '#define\s+USER_CLOSED_LOOP_DQ_VOLTAGE_LIMIT_V\s+0\.30f'
Assert-Match 'current channel 0 reads IV/Rank1' $functions '(?s)case\s+0\s*:.*?ADC_InjectedValues\[0\].*?break\s*;'
Assert-Match 'current channel 1 reads IW/Rank2' $functions '(?s)case\s+1\s*:.*?ADC_InjectedValues\[1\].*?break\s*;'
Assert-Match 'live current0 telemetry follows IV' $telemetry 'current0_live\s*=.*ADC_InjectedValues\[0\]'
Assert-Match 'live current1 telemetry follows IW' $telemetry 'current1_live\s*=.*ADC_InjectedValues\[1\]'
Assert-Match 'non-finite DQ commands are cleared' $core 'Value_isnan\(sguan->foc\.Ud_in\).*Value_isinf\(sguan->foc\.Ud_in\)'
Assert-Match 'final closed-loop limiter runs before SVPWM' $core '(?s)Limit_DqVoltageForBringup\(sguan\);\s*}\s*SVPWM_Tick\(sguan'
Assert-Match 'fault snapshot current0 follows IV' $core 'g_foc_fault_snapshot\.current0\s*=.*ADC_InjectedValues\[0\]'
Assert-Match 'fault snapshot current1 follows IW' $core 'g_foc_fault_snapshot\.current1\s*=.*ADC_InjectedValues\[1\]'

Write-Output 'FOC bring-up static safety checks passed.'
