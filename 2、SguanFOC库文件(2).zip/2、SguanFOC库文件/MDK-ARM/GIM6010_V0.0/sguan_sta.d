gim6010_v0.0\sguan_sta.o: ../SguanFOC v3.0.1/Sguan_STA.c
gim6010_v0.0\sguan_sta.o: ../SguanFOC v3.0.1/Sguan_STA.h
gim6010_v0.0\sguan_sta.o: ../SguanFOC v3.0.1/Sguan_Config.h
gim6010_v0.0\sguan_sta.o: ../SguanFOC v3.0.1/Sguan_IQmath.h
gim6010_v0.0\sguan_sta.o: C:\Users\18261\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
gim6010_v0.0\sguan_sta.o: C:\Users\18261\AppData\Local\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
gim6010_v0.0\sguan_sta.o: ../SguanFOC v3.0.1/UserData_Config.h
