#ifndef __SGUAN_PID_H
#define __SGUAN_PID_H

/* SguanFOC配置文件声明 */
#include "Sguan_Config.h"

typedef struct{
    float i[2];             // (数据)数据历史输入值
    float Io[2];            // (数据)积分历史输出值
    float Do[2];            // (数据)微分历史输出值

    float Ref;              // (输入数据)Target期望数值
    float Fbk;              // (输出数据)Real真实反馈数据
    float Output;           // (输出数据)Output输出

    float I_num;            // (中间量)积分传递函数分子系数
    float D_num;            // (中间量)微分传递函数分子系数
    float D_den[2];         // (中间量)微分传递函数分母系数

    uint8_t IntegralFrozen_flag; // (中间量)积分抗饱和
}RUN_STRUCT;

typedef struct{
    RUN_STRUCT run;         // (结构体)PID运算结构体

    double Wc;              // (参数设计)Wc微分环节一阶低通滤波
    double T;               // (参数设计)T周期

    float Kp;               // (参数设计)Kp比例项增益
    double Ki;              // (参数设计)Ki积分项增益
    double Kd;              // (参数设计)Kd微分项增益

    float OutMax;           // (参数设计)输出上限限幅
    float OutMin;           // (参数设计)输出下限限幅

    float IntMax;           // (参数设计)积分项上限
    float IntMin;           // (参数设计)积分项下限
}PID_STRUCT;


// ============================ Q31 版本代码 ============================

typedef struct{
    Q31_t i[2];             // (数据)数据历史输入值
    Q31_t Io[2];            // (数据)积分历史输出值
    Q31_t Do[2];            // (数据)微分历史输出值

    Q31_t Ref;              // (输入数据)Target期望数值
    Q31_t Fbk;              // (输出数据)Real真实反馈数据
    Q31_t Output;           // (输出数据)Output输出

    Q31_t P_num;            // (中间量)比例项增益系数
    Q31_t I_num;            // (中间量)积分传递函数分子系数
    Q31_t D_num;            // (中间量)微分传递函数分子系数
    Q31_t D_den;            // (中间量)微分传递函数分母系数

    uint8_t IntegralFrozen_flag; // (中间量)积分抗饱和

    Q31_t OutMax;           // (数据)输出上限限幅
    Q31_t OutMin;           // (数据)输出下限限幅

    Q31_t IntMax;           // (数据)积分项上限
    Q31_t IntMin;           // (数据)积分项下限
}RUN_STRUCT_q31;

typedef struct{
    RUN_STRUCT_q31 run;     // (结构体)PID运算结构体

    double Wc;              // (参数设计)Wc微分环节一阶低通滤波
    double T;               // (参数设计)T周期

    float Kp;               // (参数设计)Kp比例项增益
    double Ki;              // (参数设计)Ki积分项增益
    double Kd;              // (参数设计)Kd微分项增益

    float OutMax;           // (参数设计)输出上限限幅
    float OutMin;           // (参数设计)输出下限限幅

    float IntMax;           // (参数设计)积分项上限
    float IntMin;           // (参数设计)积分项下限

    float BASE_In;          // (数据)输入的基准值
    float BASE_Out;         // (数据)输出的基准值
}PID_STRUCT_q31;

void PID_Init(PID_STRUCT *pid);
void PID_Loop(PID_STRUCT *pid);

uint8_t PID_Init_q31(PID_STRUCT_q31 *pid);
void PID_Loop_q31(PID_STRUCT_q31 *pid);


#endif // SGUAN_PID_H
